package com.example.crudapientry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudapiEntryApplicationTests {

    @Test
    void contextLoads() {
    }

}
