package com.example.crudapientry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudapiEntryApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrudapiEntryApplication.class, args);
    }

}
